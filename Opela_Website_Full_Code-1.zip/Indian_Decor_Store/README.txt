OPELA / INDIAN DECOR STORE WEBSITE

Files:
- index.html: website content and navigation
- style.css: website design
- script.js: product catalogue, prices, cart and WhatsApp order logic
- images/: product photos

HOW TO PREVIEW
1. Keep all files and the images folder together inside Indian_Decor_Store.
2. Open index.html in a browser, or open the folder in VS Code.

HOW TO PUBLISH WITH GITHUB PAGES
Upload index.html, style.css, script.js, and the complete images folder to the root of your GitHub repository. Keep the names and folder structure unchanged.

FEATURES
- Home, About Us, Contact Us, Order Now and Cart navigation
- Product photos, prices and Per Piece labels
- Add to Cart and Order Now buttons for each product
- Cart total and remove option
- Cash on Delivery option
- Delivery fee is not added automatically; the owner confirms it based on address
- WhatsApp order message with customer details

IMPORTANT
The WhatsApp number is set to 918527270809, the contact number printed in the supplied catalogue. If this is not your own store number, change WHATSAPP_NUMBER in script.js and the contact link/number in index.html.
Orders are sent through WhatsApp. This site does not have an online payment gateway or automatic email/backend.
